from django.shortcuts import render
from . import models
from django.db.models import Count
# Create your views here.
def index(req):
    languages = models.Languages.objects.filter(language='slovene').order_by('-percentage')
    countries = models.Countries.objects.all().annotate(totalCities=Count('citytocountry__country_id')).order_by('-totalCities')
    mexico = models.Cities.objects.filter(country__name="Mexico", population__gt=500000)
    majorlang = models.Languages.objects.filter(percentage__gt=89)
    countries2 = models.Countries.objects.filter(surface_area__lt=501, population__gt=100000)
    countries3 = models.Countries.objects.filter(government_form="Constitutional Monarchy", capital__gt=200, life_expectancy__gt=75)
    buenos = models.Cities.objects.filter(country__name="Argentina", district="Buenos Aires", population__gt=500000)
    regions = models.Countries.objects.values('region').annotate(regionCount=Count('id')).order_by('-regionCount')

    print regions.query

    return render(req, 'worldApp/index.html', context={'languages':languages, 'countries':countries, 'mexico':mexico, 'majorlang':majorlang, 'countries2':countries2, 'countries3':countries3, 'buenos':buenos, 'regions':regions})
