from django.shortcuts import render
from .models import Users, Friendships
# Create your views here.
def index(req):
    # users1 = Users.objects.filter(last_name = "Rodriguez")
    # users2 = Users.objects.exclude(last_name = "Rodriguez")
    # users3 = Users.objects.filter(last_name = "Rodriguez") | Users.objects.filter(first_name = "Daniel")
    # users4 = Users.objects.filter(last_name = "Rodriguez").exclude(first_name = "Madison")
    # users5 = Users.objects.exclude(first_name = "Daniel").exclude(first_name = "Michael")
    # users6 = Users.objects.get(id = 1)
    # users9 = Users.objects.order_by('first_name')
    # users10 = Users.objects.order_by('-last_name')
    # friendships11 = Friendships.objects.raw('SELECT * from Friendships')
    # friendships12 = Friendships.objects.filter(user_id = 4)
    # friendships13 = Friendships.objects.filter(friend_id = 4)
    # friendships14 = Friendships.objects.exclude(user_id = 4).exclude(user_id = 5).exclude(user_id = 6)

    # for friendship in friendships11:
    # 	print friendship.user_id
    # 	print friendship.friend_id

    # for friendship in friendships12:
    # 	print friendship.user_id
    # 	print friendship.friend_id

    # for friendship in friendships13:
    # 	print friendship.user_id
    # 	print friendship.friend_id

    # for friendship in friendships14:
    # 	print friendship.user_id
    # 	print friendship.friend_id
    
    # context = {'users1':users1, 'users2':users2, 'users3':users3, 'users4':users4, 'users5':users5, 'users6':users6, 'users9':users9, 'users10':users10, 'friendships12':friendships12}

    friendships1 = Friendships.objects.raw('SELECT * from Friendships')
    friendships2 = Friendships.objects.filter(user__first_name='Michael')
    friendships3 = Friendships.objects.exclude(user__first_name='Daniel')
    friendships4 = Friendships.objects.filter(user_id=1) | Friendships.objects.filter(user__last_name='Hernandez')
    friendships5 = (Friendships.objects.filter(user_id=1) | Friendships.objects.filter(user__last_name='Hernandez')).order_by('friend__first_name').distinct()
    users6 = Users.objects.filter(usersfriend__friend__id=2)
    print users6.query
    users8 = (Users.objects.filter(usersfriend__user__id=1) | Users.objects.filter(last_name='Hernandez')).distinct()

    context={'friendships1':friendships1, 'friendships2':friendships2, 'friendships3':friendships3, 'friendships4':friendships4,'friendships5':friendships5, 'users6':users6, 'users8':users8}
    return render(req, "friendapp/index.html",context)
