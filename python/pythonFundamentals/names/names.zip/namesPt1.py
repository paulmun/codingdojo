students = [
	{'first_name': 'Michael', 'last_name': 'Jordan'},
	{'first_name': 'John', 'last_name': 'Roasales'},
	{'first_name': 'Mark', 'last_name': 'Guillen'},
	{'first_name': 'KB', 'last_name': 'Tonel'}
]
for i in range (len(students)):
	print students[i]['first_name'],students[i]['last_name']
