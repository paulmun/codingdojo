for count in range(1,1000001):
	if count%2 == 1:
		print count

	