for count in range(5,1000001):
	if count%5 == 0:
		print count

	