def draw_stars(x):
	for i in range (len(x)):
		print "*"*x[i]
draw_stars([5,4,3,2,1])