//
//  ViewController.swift
//  ColdCall
//
//  Created by Paul Mun on 10/31/16.
//  Copyright © 2016 Paul Mun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nameLabel: UILabel!
    var names = ["Bryant", "Uyanya", "Jimmy", "Courtney", "Ryota", "Cody"]

    @IBAction func coldCallButton(_ sender: UIButton) {
        nameLabel.text = names[Int(arc4random_uniform(5))]
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = names[Int(arc4random_uniform(5))]
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

