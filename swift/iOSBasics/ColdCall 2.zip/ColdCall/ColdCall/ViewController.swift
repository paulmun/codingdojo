//
//  ViewController.swift
//  ColdCall
//
//  Created by Paul Mun on 10/31/16.
//  Copyright © 2016 Paul Mun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    var names = ["Bryant", "Uyanya", "Jimmy", "Courtney", "Ryota", "Cody"]

    @IBAction func coldCallButton(_ sender: UIButton) {
        let number = Int(arc4random_uniform(5))
        nameLabel.text = names[number]
        numberLabel.text = String(number + 1)
        color(number: number)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let number = Int(arc4random_uniform(5))
        nameLabel.text = names[number]
        numberLabel.text = String(number + 1)
        color(number: number)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

private extension ViewController {
    func color(number: Int){
        if number < 2 {
            numberLabel.textColor = UIColor.red
        }
        else if number < 4 {
            numberLabel.textColor = UIColor.orange
        }
        else{
            numberLabel.textColor = UIColor.green
        }
    }
}

