//
//  ViewController.swift
//  TicTacToe
//
//  Created by Paul Mun on 11/1/16.
//  Copyright © 2016 Paul Mun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var winnerLabel: UILabel!
    @IBOutlet var buttons: [UIButton]!
    
    var player: Int = 1
    var board: Array<[Int]> = [
        [0,0,0],
        [0,0,0],
        [0,0,0]
    ]
    
    @IBAction func tictac(_ sender: UIButton) {
        if player != 3{
            let idx = buttons.index(of: sender)
            let row = Int(floor(Double(idx!)/3.0))
            let col = idx!%3
            print(idx!)
            if board[row][col] == 0{
                if player == 1{
                    player = 2
                    board[row][col] = 1
                    sender.backgroundColor = UIColor.red
                }
                else{
                    player = 1
                    board[row][col] = 2
                    sender.backgroundColor = UIColor.blue
                }
            }
            if boardChecker(row: row, col: col){
                winnerLabel.isHidden = false
                if player == 1{
                    winnerLabel.text = "Winner is Blue!"
                }
                else{
                    winnerLabel.text = "Winner is Red!"
                }
                player = 3
            }
            print(board)
            
        }
    }
        
    @IBAction func reset(_ sender: UIButton) {
        board = [
            [0,0,0],
            [0,0,0],
            [0,0,0]
        ]
        winnerLabel.isHidden = true
        for button in buttons{
            button.backgroundColor = UIColor.lightGray
        }
        player = 1
        print(board)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        winnerLabel.isHidden = true
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension ViewController{
    func boardChecker(row: Int, col: Int) -> Bool{
        if (row != 1 && col != 1) || (row == 1 && col == 1){
            if (board[0][0] > 0 && board[0][0] == board[1][1] && board[1][1] == board[2][2]) || (board[0][2] > 0 && board[0][2] == board[1][1] && board[1][1] == board[2][0]){
                return true
            }
        }
        if (board[row][0] > 0 && board[row][0] == board[row][1] && board[row][1] == board[row][2]) || (board[0][col] > 0 && board[0][col] == board[1][col] && board[1][col] == board[2][col]){
            return true
        }
        return false
    }
}

