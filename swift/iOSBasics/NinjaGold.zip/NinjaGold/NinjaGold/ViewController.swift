//
//  ViewController.swift
//  NinjaGold
//
//  Created by Paul Mun on 11/1/16.
//  Copyright © 2016 Paul Mun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var farmEarnings: UILabel!
    @IBOutlet weak var caveEarnings: UILabel!
    @IBOutlet weak var houseEarnings: UILabel!
    @IBOutlet weak var casinoEarnings: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    
    var score: Int = 0

    @IBAction func farmEarner(_ sender: UIButton) {
        hider()
        let number = Int(arc4random_uniform(11)+10)
        score += number
        scoreLabel.text = "Score: \(score)"
        farmEarnings.text = "You earned \(number)"
        farmEarnings.isHidden = false
    }
    
    @IBAction func caveEarner(_ sender: UIButton) {
        hider()
        let number = Int(arc4random_uniform(6)+5)
        score += number
        scoreLabel.text = "Score: \(score)"
        caveEarnings.text = "You earned \(number)"
        caveEarnings.isHidden = false
    }
    
    @IBAction func houseEarner(_ sender: UIButton) {
        hider()
        let number = Int(arc4random_uniform(4)+2)
        score += number
        scoreLabel.text = "Score: \(score)"
        houseEarnings.text = "You earned \(number)"
        houseEarnings.isHidden = false
    }
    
    @IBAction func casinoEarner(_ sender: UIButton) {
        hider()
        let number = Int(arc4random_uniform(101)) - Int(50)
        score += number
        scoreLabel.text = "Score: \(score)"
        casinoEarnings.text = "You earned \(number)"
        casinoEarnings.isHidden = false
    }
    @IBAction func resetter(_ sender: UIButton) {
        hider()
        score = 0
        scoreLabel.text = "Score: \(score)"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hider()
        scoreLabel.text = "Score: \(score)"
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension ViewController{
    func hider(){
        farmEarnings.isHidden = true
        caveEarnings.isHidden = true
        houseEarnings.isHidden = true
        casinoEarnings.isHidden = true
    }
}
