//
//  ViewController.swift
//  Tipster
//
//  Created by Paul Mun on 11/1/16.
//  Copyright © 2016 Paul Mun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var calculations: [UILabel]!
    @IBOutlet var buttons: [UIButton]!
    @IBOutlet weak var tipSlider: UISlider!
    @IBOutlet weak var subTotal: UILabel!
    @IBOutlet weak var groupSize: UISlider!
    @IBOutlet weak var groupSizeLabel: UILabel!
    
    var tipPercentage = Double()
    var subtotal = String()
    var counter = Int()
    
    @IBAction func inputKeys(_ sender: UIButton) {
        if buttons.index(of: sender)! == 11{
            if counter < 1{
                if subtotal == ""{
                    subtotal = subtotal + "0."
                }
                else{
                    subtotal = subtotal + "."
                    subTotal.text = subtotal
                }
                counter += 1
            }
        }
        else if buttons.index(of: sender)! == 10 && counter < 3{
            subtotal = subtotal + "0"
            subTotal.text = subtotal
            if counter > 0{
                counter += 1
            }
        }
        else if buttons.index(of: sender)! != 9 && counter < 3{
            subtotal = subtotal + String(buttons.index(of: sender)!+1)
            subTotal.text = subtotal
            if counter > 0{
                counter += 1
            }
        }
        else if buttons.index(of: sender)! == 9{
            subtotal = ""
            counter = 0
            subTotal.text = "0"
        }
        calc()
    }
    
    @IBAction func tipPercentChanged(_ sender: UISlider) {
        sender.value = round(sender.value*100)/100
        tipPercentage = Double(sender.value)
        print(sender.value)
        calc()
    }
    
    @IBAction func groupSizeChanged(_ sender: UISlider) {
        sender.value = round(sender.value)
        groupSizeLabel.text = "Group Size: \(Int(groupSize.value))"
        calc()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        subTotal.text = "0"
        tipPercentage = 0.05
        calc()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewController{
    func calc(){
        for i in 0...2{
            calculations[i].text = "\(Int(round(tipPercentage * 100)) + (i * 5))%"
        }
        
        for i in 0...2{
            calculations[i+3].text = "\(round((tipPercentage + (Double(i) * 0.05)) * (subtotal as NSString).doubleValue / Double(groupSize.value) * 100) / 100)"
        }
        
        for i in 6...8{
            calculations[i].text = "\(round((subtotal as NSString).doubleValue/Double(groupSize.value)*100)/100 + (calculations[i-3].text! as NSString).doubleValue)"
        }
    }
}

