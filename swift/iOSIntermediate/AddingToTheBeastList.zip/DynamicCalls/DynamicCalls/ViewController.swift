//
//  ViewController.swift
//  DynamicCalls
//
//  Created by Paul Mun on 11/3/16.
//  Copyright © 2016 Paul Mun. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource{
    var tasks = ["Exercise for 30 minutes", "Wireframe for some project", "Do laundry"]
    
    @IBOutlet weak var insertTaskField: UITextField!
    @IBOutlet weak var tableView: UITableView!

    @IBAction func insertButtonPressed(_ sender: UIButton) {
        if (insertTaskField.text != nil){
            tasks.append(insertTaskField.text!)
        }
        insertTaskField.text = ""
        tableView.reloadData()
    }
    
    func tableView(_ sender: UITableView, numberOfRowsInSection: Int) -> Int{
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell")!
        cell.textLabel?.text = tasks[indexPath.row]
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

