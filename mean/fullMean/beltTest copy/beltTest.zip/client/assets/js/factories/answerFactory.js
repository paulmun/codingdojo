app.factory('answerFactory', ['$http', function($http){


	function AnswerFactory(){
		this.create = function(questionId, answer, userId, callback){
			
		}

	}
	return new AnswerFactory();
}]);
		
		