var mongoose = require('mongoose');
var Friend = mongoose.model('Friend');

function friendsController(){
	this.index = function(req, res){
		var friends = Friend.find({}, function(err,friends){
			res.json(friends);
		});
	};
	this.create = function(req, res){
		var friend = new Friend({firstName: req.body.firstName, lastName: req.body.lastName, birthday: req.body.birthday});
		friend.save(function(err){
			if(err){
				console.log(err);
			}
			res.json(friend);
		});
	};
	this.update = function(req, res){
		var data = req.data;
		Friend.findById(req.params.id, function(err, friend){
			friend.firstName = data.firstName;
			friend.lastName = data.lastName;
			friend.birthday = data.birthday;
			friend.save(function(err){
				if(err){
					console.log(err);
				}
			});
		})

	};
	this.deleted = function(req, res){
		console.log(req.params.id)
		Friend.findByIdAndRemove(req.params.id, function(err){
			Friend.find({}, function(err, friends){
			if(err){
				console.log(err);
			}
			res.json(friends);
			});
		});
	};
	this.show = function(req, res){
		Friend.findById(req.body.id, function(err, friend){
			if(err){
				console.log(err);
			}
			res.json(friend);
		});
	};
}

module.exports = new friendsController();