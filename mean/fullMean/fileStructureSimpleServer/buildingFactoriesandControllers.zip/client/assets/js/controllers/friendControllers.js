app.controller('newController', ['$scope', '$location', 'friendsFactory', function($scope, $location, friendsFactory){
	
	$scope.addFriend = function(){
		friendsFactory.create($scope.friend, function(data){
			$scope.newFriend = data;
		});
		$scope.friend = {};
		$location.url('/');
	}
}]);

app.controller('editController', ['$scope', '$routeParams', 'friendsFactory', function($scope, $routeParams, friendsFactory){
	friendsFactory.show($routeParams.id, function(data){
		$scope.friend = data;
		console.log($scope.friend);
	});

	$scope.editFriend = function(){
		friendsFactory.update($scope.friend.id, $scope.friend)
	}

	$scope.deleteFriend = function(){

	}
}]);

app.controller('showController', ['$scope', '$routeParams', 'friendsFactory', function($scope, $routeParams, friendsFactory){
	friendsFactory.show($routeParams.id, function(data){
		$scope.friend = data;
	});
}]);

app.controller('indexController', ['$scope', '$location', 'friendsFactory', function($scope, $location, friendsFactory){
	friendsFactory.index(function(data){
		$scope.friends = data;
	});
	$scope.deleteFriend = function(id){
		friendsFactory.delete(id, function(data){
			$scope.friends = data; 
		});
		
	};
}])