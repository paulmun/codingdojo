app.controller('newController', ['$scope', function($scope){
	$scope.friend = {}
	$scope.addFriend = function(){
		
	}
}]);

app.controller('editController', ['$scope', function($scope){
	$scope.friend = {}
	$scope.editFriend = function(){

	}
}]);