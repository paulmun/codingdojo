var mongoose = require('mongoose');
var Friend = mongoose.model('Friend');

function friendsController(){
	this.index = function(req, res){
		var friends = Friend.find({}, function(err,friends){
			res.json(friends);
		});
	};
	this.create = function(req, res){
		var friend = new Friend({firstName: req.params.firstName, lastName: req.params.lastName, birthday: req.params.birthday});
		friend.save(function(err){
			if(err){
				console.log(err);
			}
			res.json(friend);
		});
	};
	this.update = function(req, res){
		var data = req.data;
		Friend.findById(req.params.id, function(err, friend){
			friend.firstName = data.firstName;
			friend.lastName = data.lastName;
			friend.birthday = data.birthday;
			friend.save(function(err){
				if(err){
					console.log(err);
				}
				res.redirect('/');
			});
		})

	};
	this.deleted = function(req, res){
		Friend.remove({_id:req.params.id}, function(err){
			if(err){
				console.log(err);
			}
			res.redirec('/');
		});
	};
	this.show = function(req, res){
		Friend.findById(req.params.id, function(err, friend){
			res.json(friend);
		});
	};
}

module.exports = new friendsController();