var mongoose = require('mongoose');

var FriendSchema = new mongoose.Schema({
	firstName: String,
	lastName: String,
	birthday: Date,
})

var Friend = mongoose.model('Friend', FriendSchema);