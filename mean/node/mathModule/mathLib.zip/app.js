var mathlib = require('./mathlib')();

console.log(mathlib.add(5,4));
console.log(mathlib.multiply(5,4));
console.log(mathlib.square(4));